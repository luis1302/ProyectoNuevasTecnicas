<html>
<link rel="stylesheet" href="css/estilos.css" >
  <head>

    <tittle>Deber Luis Ramirez</tittle>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
      $(document).ready(function(){
        $("#celular").keypress(function(tecla) {
        if(tecla.charCode < 48 || tecla.charCode > 57 )
          return false;
          if($('#celular').val().length >= 10)
           return false;
        });
        $('#email').focusout(function() {
				if (!$('#email').val().includes("@") || !$('#email').val().includes(".com")) {
          !$('#error').html('')
          $("<img src='triste.png'></img>").appendTo("#error");
				}
				else {
            !$('#error').html('')
					$("<img src='feliz.png'></img>").appendTo("#error");
				}
			});
      });
    </script>
  </head>

  <body>
    <form action = "/guardar" method="POST">
      {{csrf_field()}}
      <h1><one>FORMULARIO CONTACTO</one></h1>
      <p><st> Ingrese su nombre </st></p>
      <input id="nombre" name="nombre" type="text"/></br>
      <div>
        <p><st> Ingrese su Email </st></p>
        <input id="email" name="email" type="text"/><div style="display:inline; margin-left: 20px" id="error"></div></br>
      </div>
      <p><st>Ingrese su celular</st></p>
      <input type="text" name="celular" id="celular"></br>

    </br><button class="button" type="submit" id="boton">Guardar</button>
    </form>
  </body>
</html>
