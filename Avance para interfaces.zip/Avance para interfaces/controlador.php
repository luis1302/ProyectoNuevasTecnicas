<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\persona;
class controlador extends Controller
{
    //
    public function ingreso(Request $request)
   {
      $registro = new persona();
      $registro->nombre = $request->input('nombre');
      $registro->email = $request->input('email');
      $registro->celular = $request->input('celular');
      $registro->save();
        return 'Persona ingresada exitosamente';
   }
}
