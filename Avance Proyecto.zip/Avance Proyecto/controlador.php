<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\persona;
use App\pregunta;
class controlador extends Controller
{
    //
    public function ingreso(Request $request)
   {
      $registro = new persona();
      $registro->nombre = $request->input('nombre');
      $registro->email = $request->input('email');
      $registro->celular = $request->input('celular');
      $registro->save();
      return "Guardado Exitoso";
   }

   public function cargar()
  {
      $registro = pregunta::all();
      return view('mensaje',compact('registro'));
  }
}
