<html>
<link rel="stylesheet" href="css/estilos.css" >
  <head>

    <tittle></tittle>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
      $(document).ready(function(){
        $("#celular").hide();
        $("#email").hide();
        $('select#cmb').on('change',function(){
          if($("#cmb").val()=="celular"){
            $("#celular").show();
            $("#celular").keypress(function(tecla) {
            if(tecla.charCode < 48 || tecla.charCode > 57 )
              return false;
              if($('#celular').val().length >= 10)
               return false;
            });
        }

        if($("#cmb").val()=="email"){
          $("#email").show();
          $('#email').focusout(function() {
  				if (!$('#email').val().includes("@") || !$('#email').val().includes(".com")) {
            !$('#error').html('')
            $("<img src='triste.png'></img>").appendTo("#error");
  				}
  				else {
              !$('#error').html('')
  					$("<img src='feliz.png'></img>").appendTo("#error");
  				}
  			});
      }
      });

      $("#boton").click(function(){
        $("#forma").fadeOut("slow");
        $("#error2").html("Enviando");
        $.post("/guardar",$("#forma").serialize()).done(function(dato){
          $("#error2").html(dato);
        });

      });

      /*$(".accordion-titulo").click(function(){

        var contenido=$(this).next(".accordion-content");

         if(contenido.css("display")=="none"){ //open
            contenido.slideDown(250);
            $(this).addClass("open");
         }
         else{ //close
            contenido.slideUp(250);
            $(this).removeClass("open");
        }

      });
      $.get("/cargar",$("#contenido").val()).done(function(dato){
        $("#titulo").html(dato);
      });*/

      $("#boton2").click(function(){
             	$.ajax({
				type: 'get',
				url: '/guardar',
                success: function(data){
                    $("#error").html(data);
                }
			});
    });


    });
    </script>
  </head>

  <body>
    <form id="forma">
      {{csrf_field()}}
      <h1><one>FORMULARIO CONTACTO</one></h1>
      <p><st> Ingrese su nombre </st></p>
      <input id="nombre" name="nombre" type="text"/></br></br>
      <select name="cmb" id="cmb">
          <option value="op">Medio de Contacto</option>
          <option value="email">email</option>
          <option value="celular">celular</option>
      </select></br></br>
      <div>
        <input id="email" name="email" type="text" placeholder="Ingrese Email"/><div style="display:inline; margin-left: 20px" id="error"></div></br></br>
      </div>
      <input type="text" name="celular" id="celular" placeholder="Ingrese Celular"></br>

    </br><button class="button" type="button" id="boton">Guardar</button>
			<input  id="boton2" name= "boton" type="button" value="Preguntas Frecuentes"  />
    <p id="error2"> </p></br>

  </form>


  </body>
</html>
