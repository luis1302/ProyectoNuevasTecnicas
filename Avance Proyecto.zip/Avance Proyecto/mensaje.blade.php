<html>
<head>


<script>
    $(document).ready(function(){
        $("#boton3").click(function(){
              $.ajax({
              type: 'get',
              url: '/validar',
                success: function(data){
                    $("#error").html(data);
                }
      });
    });
    });

  </script>

<style>
.accordion {
  background-color: #eee;
  color: #444;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
  transition: 0.4s;
}

.active, .accordion:hover {
  background-color: #ccc;
}

.panel {
  padding: 0 18px;
  display: none;
  background-color: white;
  overflow: hidden;
}
</style>
</head>
<body>
 <h2>Preguntas Frecuentes</h2>
@foreach ($registro as $dato)
<button class="accordion" id="boton3">{{$dato->nombre}}</button>
<div class="panel">
  <p>{{$dato->contenido}} </p>
</div>
@endforeach

<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}
</script>
 <div id="error"> </div>
</body>

</html>
