<?php

namespace App\Http\Controllers;

use App\pregunta;
use Illuminate\Http\Request;

class consulta extends Controller
{
    //

    public function cargar()
   {
       $registro = \App\pregunta::all();
       return view('principal',compact('registro'));
   }
}
