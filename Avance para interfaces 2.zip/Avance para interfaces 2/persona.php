<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class persona extends Model
{
    //
    public $timestamps=false;
    protected $fillable = ['nombre','email','celular'];
}
