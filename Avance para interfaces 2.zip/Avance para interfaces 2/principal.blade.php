<html>
<link rel="stylesheet" href="css/estilos.css" >
  <head>

    <tittle>Deber Luis Ramirez</tittle>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
      $(document).ready(function(){
        $("#celular").hide();
        $("#email").hide();
        $('select#cmb').on('change',function(){
          if($("#cmb").val()=="celular"){
            $("#celular").show();
            $("#celular").keypress(function(tecla) {
            if(tecla.charCode < 48 || tecla.charCode > 57 )
              return false;
              if($('#celular').val().length >= 10)
               return false;
            });
        }

        if($("#cmb").val()=="email"){
          $("#email").show();
          $('#email').focusout(function() {
  				if (!$('#email').val().includes("@") || !$('#email').val().includes(".com")) {
            !$('#error').html('')
            $("<img src='triste.png'></img>").appendTo("#error");
  				}
  				else {
              !$('#error').html('')
  					$("<img src='feliz.png'></img>").appendTo("#error");
  				}
  			});
      }
      });
      $("#boton").click(function(){
        $("#forma").fadeOut("slow");
        $("#error").html("Enviando");
      });
      });
    </script>
  </head>

  <body>
    <form id="forma" action = "/guardar" method="POST">
      {{csrf_field()}}
      <h1><one>FORMULARIO CONTACTO</one></h1>
      <p><st> Ingrese su nombre </st></p>
      <input id="nombre" name="nombre" type="text"/></br></br>
      <select name="cmb" id="cmb">
          <option value="op">Medio de Contacto</option>
          <option value="email">email</option>
          <option value="celular">celular</option>
      </select></br></br>
      <div>
        <input id="email" name="email" type="text" placeholder="Ingrese Email"/><div style="display:inline; margin-left: 20px" id="error"></div></br></br>
      </div>
      <input type="text" name="celular" id="celular" placeholder="Ingrese Celular"></br>

    </br><button class="button" type="submit" id="boton">Guardar</button>
    <p id="error"> </p>
    </form>
  </body>
</html>
