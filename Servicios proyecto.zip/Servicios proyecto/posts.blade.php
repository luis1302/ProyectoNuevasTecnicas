<html>
  <head>
    <title> Indicadores </title>
    </style>
  </head>

<body>
  <h1>DATOS OTRA BASE</h1><br>
  @foreach($listado as $listado)
  {{$listado->nombre}}<br>
  {{$listado->venta}}<br>
  {{$listado->direccion}}<br><br>
  @endforeach
  <h1>DATOS MI BASE</h1><br>
  @foreach($locales as $lo)
  {{$lo->nombre}}<br>
  {{$lo->ventas}}<br>
  @endforeach

</body>
  </html>
