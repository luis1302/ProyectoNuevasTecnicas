<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\tienda;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;

class demoguzzle extends Controller
{
    //
    function consultarPosts(){
      $cliente = new Client();
      $resultado = $cliente->get('https://jsonplaceholder.typicode.com/posts');
      //print_r($resultado);//sirve para saber que hay dentro de lo que deseemos
      return view('posts',['listadoPosts'=>json_decode($resultado->getBody())]);
    }
    function consulta(){
      $cli = new Client();
      $res = $cli->get('http://172.16.0.106:8000/api/ventas');
      $locales = \App\tienda::all();
      return view('posts',['listado'=>json_decode($res->getBody()), 'locales'=>$locales]);
    }

}
