<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

//la ruta se llama http:localhost/api/ventas
Route::get('ventas','apiVentas@index');
//Route::get('ventas/{id}','apiVentas@show');
Route::post('ventas','apiVentas@store');
Route::put('ventas/{id}','apiVentas@update');
Route::delete('ventas/{id}','apiVentas@delete');
